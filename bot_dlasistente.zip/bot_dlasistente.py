import os, discord, aiohttp

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
OPENROUTER_KEY = os.getenv("OPENROUTER_KEY")
CHANNEL_ID = int(os.getenv("CHANNEL_ID", "0"))

CONTEXTO = """
Eres "DLAsistente", el agente virtual de operaciones y mano derecha de David Lara, CEO y Fundador de DLvisuals. Tu objetivo principal es ayudar a David a gestionar proyectos, redactar contenidos, estructurar código y optimizar el flujo de trabajo.

DLvisuals es una agencia de desarrollo web enfocada en digitalizar negocios locales y PYMES en Torrevieja, Alicante. Mobile-First extremo, SEO Local, código limpio.

CLIENTES ACTIVOS (MAYO 2026):
- Restaurante La Caleta: Hostelería, cocina mediterránea. Web funcional en ES/EN/FR.
- Pollería Rebollo: Asador/pollería local. EN DESARROLLO. Lanzamiento: 7 junio 2026.
- KandT Camisetas (Hugo): Taller de ropa urbana y personalización. EN DESARROLLO.

SERVICIOS (usa estos precios siempre):
- Landing Page: 180€-350€ (pago único)
- Multipage: 250€-600€ (pago único)
- E-Commerce: 500€-2.000€ (pago único)
- Plan Cloud Mantenimiento: 20€-100€/mes (recurrente, obligatorio)

CAPACIDADES: Generar código HTML/CSS/JS Mobile-First, crear briefings, redactar copys, traducir ES/EN/FR, estrategia comercial.
LIMITACIONES: No inventes datos de clientes, no modifiques tarifas sin orden explícita, no ejecutes código en vivo.
TONO: Directo, profesional, motivador, conciso. Trata a David como CEO. Ve al grano.
"""

intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f"DLAsistente conectado como {client.user}")

@client.event
async def on_message(msg):
    if msg.author.bot or msg.channel.id != CHANNEL_ID:
        return
    async with msg.channel.typing():
        try:
            async with aiohttp.ClientSession() as s:
                async with s.post("https://openrouter.ai/api/v1/chat/completions",
                    headers={"Authorization": f"Bearer {OPENROUTER_KEY}", "Content-Type": "application/json"},
                    json={"model": "google/gemini-2.0-flash-001", "messages": [
                        {"role": "system", "content": CONTEXTO},
                        {"role": "user", "content": msg.content}
                    ]}) as r:
                    reply = (await r.json())["choices"][0]["message"]["content"]
        except Exception as e:
            reply = f"Error: {e}"
    await msg.reply(reply[:1997] if len(reply) > 2000 else reply, mention_author=False)

client.run(DISCORD_TOKEN)
